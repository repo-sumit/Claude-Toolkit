(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});

	// A small "Export" pill that tracks the bottom edge of the LAST conversation
	// turn, so it sits near Claude's own message action row. It uses fixed
	// positioning (re-evaluated on scroll/resize) and hides when the last turn
	// is off-screen or there's no conversation. Everything degrades gracefully
	// if the turn selectors drift — the pill just stays hidden.
	class InlineExport {
		constructor({ onOpenPanel } = {}) {
			this.onOpenPanel = onOpenPanel || (() => {});
			this.settings = CT.DEFAULTS;
			this.visible = false;
			this.lastTurn = null;
			this._raf = null;
			this._built = false;
			this._lastRefresh = 0;
		}

		mount(settings) {
			if (this._built) return;
			this._built = true;
			this.settings = settings;

			const pill = document.createElement('button');
			pill.type = 'button';
			pill.className = 'ct-inlineexp';
			pill.setAttribute('aria-haspopup', 'dialog');
			pill.setAttribute('aria-expanded', 'false');
			pill.setAttribute('aria-label', 'Export this conversation');
			pill.innerHTML = '<span aria-hidden="true">⤓</span><span class="ct-inlineexp__txt">Export</span>';
			pill.addEventListener('click', () => this._toggleMenu());
			document.body.appendChild(pill);
			CT.a11y.decorate(pill);
			this.pill = pill;

			window.addEventListener('resize', () => this._schedule());
			window.addEventListener('scroll', () => this._schedule(), true);
			if (window.visualViewport) window.visualViewport.addEventListener('resize', () => this._schedule());
			this._watch = setInterval(() => {
				this.refresh();
				this._schedule();
			}, 600);

			this.refresh();
			this._schedule();
		}

		setSettings(s) {
			this.settings = s;
			if (!s.showInlineExport) this._hide();
			this._schedule();
		}

		// Re-find the last turn (throttled so streaming updates stay cheap).
		refresh() {
			const now = Date.now();
			if (now - this._lastRefresh < 400) return;
			this._lastRefresh = now;
			let turns = [];
			for (const sel of CT.SEL.TURNS) {
				turns = Array.from(document.querySelectorAll(sel));
				if (turns.length) break;
			}
			this.lastTurn = turns.length ? turns[turns.length - 1] : null;
		}

		_schedule() {
			if (this._raf) return;
			this._raf = requestAnimationFrame(() => {
				this._raf = null;
				this._position();
			});
		}

		_position() {
			if (!this.settings?.showInlineExport || !CT.state.conversation) return this._hide();
			if (!this.lastTurn || !this.lastTurn.isConnected) {
				this.refresh();
				if (!this.lastTurn) return this._hide();
			}
			const r = this.lastTurn.getBoundingClientRect();
			// Hide when the message's bottom isn't comfortably in view.
			if (r.bottom < 60 || r.bottom > window.innerHeight - 8 || r.width < 80) return this._hide();

			const pw = this.pill.offsetWidth || 78;
			let left = r.left;
			// Keep clear of the side panel when it's open.
			const maxRight = (CT.ui.panelOpen ? window.innerWidth - 360 : window.innerWidth) - 8;
			if (left + pw > maxRight) left = maxRight - pw;
			left = Math.max(8, left);
			this.pill.style.left = `${left}px`;
			this.pill.style.top = `${r.bottom + 2}px`;

			if (!this.visible) {
				this.visible = true;
				this.pill.classList.add('ct-inlineexp--show');
			}
		}

		_hide() {
			this.visible = false;
			this.pill?.classList.remove('ct-inlineexp--show');
		}

		_toggleMenu() {
			CT.popover.toggle('inlineexport', () => this._openMenu());
		}

		_openMenu() {
			const conv = CT.state.conversation;
			const anchorRect = this.pill.getBoundingClientRect();
			return CT.popover.show({
				title: 'Export conversation',
				kind: 'inlineexport',
				width: 260,
				anchorRect,
				triggerEl: this.pill,
				build: (body, api) => {
					const note = document.createElement('div');
					note.className = 'ct-exportnote';
					note.setAttribute('role', 'status');

					const act = (label, fn) => {
						const b = document.createElement('button');
						b.type = 'button';
						b.className = 'ct-menuitem';
						b.textContent = label;
						b.addEventListener('click', () => fn(b));
						return b;
					};
					const wrap = document.createElement('div');
					wrap.className = 'ct-menulist';

					if (!conv) {
						note.textContent = 'Open a conversation first.';
						body.append(wrap, note);
						api.place();
						return;
					}

					wrap.append(
						act('Copy as Markdown', async () => {
							note.textContent = (await CT.exporter.copyMarkdown(conv)) ? 'Copied Markdown ✓' : 'Clipboard blocked — try Download';
						}),
						act('Copy last answer', async () => {
							const md = CT.exporter.lastAssistantMarkdown(conv);
							note.textContent = !md ? 'No Claude answer found' : (await CT.exporter.copyText(md)) ? 'Copied last answer ✓' : 'Clipboard blocked';
						}),
						act('Copy last code block', async () => {
							const blk = CT.exporter.lastCodeBlock(conv);
							note.textContent = !blk ? 'No code block found' : (await CT.exporter.copyText(blk.code)) ? `Copied ${blk.lang || 'code'} ✓` : 'Clipboard blocked';
						}),
						act('Download .md', () => {
							CT.exporter.downloadMarkdown(conv);
							note.textContent = 'Markdown downloaded ✓';
						}),
						act('Print / Save as PDF', () => {
							note.textContent = CT.exporter.printView(conv) ? 'Opened print view' : 'Popup blocked — allow popups';
						}),
						act('More export options…', () => {
							api.close();
							this.onOpenPanel();
						})
					);
					body.append(wrap, note);
					api.place();
				}
			});
		}
	}

	CT.InlineExport = InlineExport;
})();
