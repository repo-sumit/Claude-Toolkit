(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});
	const { fmtTokens, fmtClock, fmtCountdown, esc } = CT.u;

	const METRIC_HELP = {
		ctx: 'How full this conversation\u2019s 200k context window is.',
		cache: 'Claude caches the conversation ~5 min after each reply — sending within the window is faster.',
		five: 'Rolling 5-hour session usage (from claude.ai\u2019s usage API).',
		seven: 'Rolling 7-day usage (from claude.ai\u2019s usage API).'
	};

	// Thin composer telemetry strip. Sits just outside the composer box (below,
	// flipping above if there's no room) so it never overlaps Claude's model
	// selector, effort selector, attachments, mic, or send button.
	class BottomBar {
		constructor({ onOpenPanel } = {}) {
			this.onOpenPanel = onOpenPanel || (() => {});
			this.settings = CT.DEFAULTS;
			this.visible = false;
			this.mode = 'wide';
			this._raf = null;
			this._lastRect = null;
			this._suggestion = null;
			this._built = false;
		}

		mount(settings) {
			if (this._built) return;
			this._built = true;
			this.settings = settings;

			const bar = document.createElement('div');
			bar.className = 'ct-strip';
			bar.setAttribute('role', 'group');
			bar.setAttribute('aria-label', 'Claude usage');
			CT.a11y.decorate(bar);
			bar.innerHTML = `
				<button class="ct-strip__usage" data-act="usage" aria-haspopup="dialog" aria-expanded="false" aria-label="Usage details">
					<span class="ct-seg" data-seg="five"><span class="ct-seg__txt"></span><span class="ct-rail"><i></i></span></span>
					<span class="ct-seg__div" aria-hidden="true"></span>
					<span class="ct-seg" data-seg="seven"><span class="ct-seg__txt"></span><span class="ct-rail"><i></i></span></span>
					<span class="ct-seg__div" data-div="ctx" aria-hidden="true"></span>
					<span class="ct-seg ct-seg--text" data-seg="ctx"><span class="ct-seg__txt"></span></span>
					<span class="ct-seg__div" data-div="cache" aria-hidden="true"></span>
					<span class="ct-seg ct-seg--text" data-seg="cache" hidden><span class="ct-seg__txt"></span></span>
					<span class="ct-seg__div" data-div="model" aria-hidden="true"></span>
					<span class="ct-seg ct-seg--text ct-seg--model" data-seg="model" hidden><span class="ct-seg__txt"></span></span>
				</button>
				<button class="ct-strip__icon" data-act="tools" aria-haspopup="dialog" aria-expanded="false" aria-label="Quick Tools" title="Quick Tools (Ctrl/Cmd+Shift+K)">⚡</button>
				<button class="ct-strip__icon" data-act="panel" aria-label="Open Claude Toolkit panel" title="Open panel">⊞</button>`;
			document.body.appendChild(bar);
			this.bar = bar;
			this.usageBtn = bar.querySelector('[data-act="usage"]');
			this.toolsBtn = bar.querySelector('[data-act="tools"]');

			this.usageBtn.addEventListener('click', () => this.toggleUsagePopover());
			this.toolsBtn.addEventListener('click', () => {
				CT.popover.toggle('tools', () => CT.tools.openLauncher(this.toolsBtn.getBoundingClientRect(), this.toolsBtn));
			});
			bar.querySelector('[data-act="panel"]').addEventListener('click', () => this.onOpenPanel());

			// Live draft → model suggestion (read-only).
			document.addEventListener(
				'input',
				(e) => {
					const ed = CT.getComposer();
					if (ed && (e.target === ed || ed.contains(e.target))) this._updateModel();
				},
				true
			);

			// Positioning: ResizeObserver on composer + layout, events, cheap watch.
			this.ro = new ResizeObserver(() => this.schedule());
			this.layoutRo = new ResizeObserver(() => this.schedule());
			try {
				this.layoutRo.observe(document.documentElement);
			} catch {
				/* ignore */
			}
			window.addEventListener('resize', () => this.schedule());
			window.addEventListener('scroll', () => this.schedule(), true);
			if (window.visualViewport) window.visualViewport.addEventListener('resize', () => this.schedule());
			this._watch = setInterval(() => this._cheapWatch(), 400);

			this.acquire();
			this.schedule();
			this.render();
		}

		setSettings(s) {
			this.settings = s;
			if (!s.showBottomBar) this._hide();
			this.render();
			this.schedule();
		}

		// ---- composer acquisition + positioning ----
		acquire() {
			const ed = CT.getComposer();
			if (ed !== this.ed) {
				if (this.ed) try { this.ro.unobserve(this.ed); } catch {}
				this.ed = ed || null;
				if (this.ed) try { this.ro.observe(this.ed); } catch {}
			}
		}
		schedule() {
			if (this._raf) return;
			this._raf = requestAnimationFrame(() => {
				this._raf = null;
				this.acquire();
				this.position();
			});
		}
		_cheapWatch() {
			if (!this.ed || !this.ed.isConnected) {
				this.acquire();
				this.schedule();
				return;
			}
			const r = this.ed.getBoundingClientRect();
			const l = this._lastRect;
			if (!l || Math.abs(l.top - r.top) > 1 || Math.abs(l.left - r.left) > 1 || Math.abs(l.width - r.width) > 1) this.schedule();
		}

		position() {
			if (!this.settings?.showBottomBar) return this._hide();
			if (!this.ed || !this.ed.isConnected) return this._hide();
			const r = this.ed.getBoundingClientRect();
			this._lastRect = { top: r.top, left: r.left, width: r.width };
			if (r.width < 120) return this._hide();

			this._applyMode(r.width);

			let stripW = Math.min(r.width, 840);
			// Keep clear of the side panel when it's open.
			const panelGap = CT.ui.panelOpen ? 360 : 8;
			const maxRight = window.innerWidth - panelGap;
			let left = r.left + (r.width - stripW) / 2;
			if (left + stripW > maxRight) left = maxRight - stripW;
			left = Math.max(8, left);
			if (left + stripW > window.innerWidth - 8) stripW = window.innerWidth - 8 - left;

			this.bar.style.width = `${Math.max(160, stripW)}px`;
			this.bar.style.left = `${left}px`;

			const h = this.bar.offsetHeight || 26;
			let top = r.bottom + 6; // below the composer
			if (top + h > window.innerHeight - 4) top = r.top - h - 6; // flip above
			if (top < 4) return this._hide();
			this.bar.style.top = `${top}px`;

			if (!this.visible) {
				this.visible = true;
				this.bar.classList.add('ct-strip--show');
			}
		}

		_applyMode(width) {
			let mode = 'wide';
			if (this.settings.bottomBarCompact) mode = width >= 520 ? 'narrow' : 'tiny';
			else if (width >= 900) mode = 'wide';
			else if (width >= 640) mode = 'mid';
			else if (width >= 430) mode = 'narrow';
			else mode = 'tiny';
			this.bar.dataset.mode = mode;
			this.mode = mode;
			this.render(); // labels depend on mode
		}

		// ---- model suggestion ----
		_updateModel() {
			const ed = CT.getComposer();
			const text = ed ? (ed.textContent || '').trim() : '';
			const ctxPct = CT.state.map?.count ? Math.min(100, (CT.state.map.total / CT.CONST.CONTEXT_LIMIT_TOKENS) * 100) : 0;
			this._suggestion = text ? CT.model.suggestModel({ text, contextPct: ctxPct, hasAttachment: CT.detectAttachment?.() }) : null;
			this._renderModel();
		}
		_renderModel() {
			const seg = this.bar.querySelector('[data-seg="model"]');
			const div = this.bar.querySelector('[data-div="model"]');
			const show = this.settings.showModelSuggestion !== false && this._suggestion && (this.mode === 'wide' || this.mode === 'narrow');
			seg.hidden = !show;
			if (div) div.hidden = !show;
			if (!show) return;
			const label = this.mode === 'wide' ? `Suggested: ${this._suggestion.model}` : this._suggestion.model;
			seg.querySelector('.ct-seg__txt').textContent = label;
			this.usageBtn.setAttribute('title', `Suggested model: ${this._suggestion.model} — ${this._suggestion.reason}`);
		}

		// ---- value rendering ----
		render() {
			if (!this._built) return;
			const map = CT.state.map;
			const usage = CT.state.usage;
			const wide = this.mode === 'wide';
			const mid = this.mode === 'mid';

			const setUsageSeg = (seg, w, longLabel, shortLabel, name) => {
				const el = this.bar.querySelector(`[data-seg="${seg}"]`);
				const txt = el.querySelector('.ct-seg__txt');
				const rail = el.querySelector('.ct-rail i');
				const pct = w?.utilization;
				const lvl = pct == null ? null : CT.usage.level(pct);
				el.classList.remove('ct-lvl-healthy', 'ct-lvl-moderate', 'ct-lvl-high', 'ct-lvl-critical');
				if (lvl) el.classList.add(`ct-lvl-${lvl.key}`);
				if (rail) {
					rail.style.width = `${pct || 0}%`;
					rail.className = '';
					rail.classList.add(`ct-lvlbg-${lvl ? lvl.key : 'healthy'}`);
				}
				if (pct == null) {
					txt.textContent = `${wide || mid ? longLabel : shortLabel} —`;
				} else if (wide && w.resets_at) {
					txt.textContent = `${longLabel}: ${pct.toFixed(pct < 10 ? 1 : 0)}% · resets in ${fmtCountdown(Date.parse(w.resets_at))}`;
				} else {
					txt.textContent = `${wide || mid ? longLabel : shortLabel} ${pct.toFixed(pct < 10 ? 1 : 0)}%`;
				}
				const resets = w?.resets_at ? `, resets in ${fmtCountdown(Date.parse(w.resets_at))}` : '';
				el.setAttribute('aria-label', `${name} ${pct == null ? 'unknown' : Math.round(pct) + ' percent'}${lvl ? ', ' + lvl.label : ''}${resets}`);
			};
			setUsageSeg('five', usage?.five_hour, 'Session', '5h', 'Session usage');
			setUsageSeg('seven', usage?.seven_day, 'Weekly', '7d', 'Weekly usage');

			// Context (text only)
			const ctxSeg = this.bar.querySelector('[data-seg="ctx"]');
			const ctxTxt = ctxSeg.querySelector('.ct-seg__txt');
			let ctxPct = null;
			if (map?.count) {
				ctxPct = Math.min(100, (map.total / CT.CONST.CONTEXT_LIMIT_TOKENS) * 100);
				const lvl = CT.usage.level(ctxPct);
				ctxSeg.classList.remove('ct-lvl-healthy', 'ct-lvl-moderate', 'ct-lvl-high', 'ct-lvl-critical');
				ctxSeg.classList.add(`ct-lvl-${lvl.key}`);
				ctxTxt.textContent = `Ctx ${ctxPct.toFixed(ctxPct < 10 ? 1 : 0)}%`;
				ctxSeg.setAttribute('aria-label', `Context window ${Math.round(ctxPct)} percent, ${lvl.label}`);
			} else {
				ctxTxt.textContent = 'Ctx —';
			}

			this._renderCache();
			this._renderModel();
		}

		_renderCache() {
			const seg = this.bar.querySelector('[data-seg="cache"]');
			const div = this.bar.querySelector('[data-div="cache"]');
			const cu = CT.state.map?.cachedUntil;
			// Spec: only render cache in the strip while it's actively counting down.
			const isCacheActive = cu && Date.now() < cu;
			const show = isCacheActive && this.settings.showCacheCountdown !== false && (this.mode === 'wide' || this.mode === 'mid');
			seg.hidden = !show;
			if (div) div.hidden = !show;
			if (show) {
				seg.querySelector('.ct-seg__txt').textContent = `Cache ${fmtClock(cu)}`;
				seg.setAttribute('aria-label', `Prompt cache active, ${fmtClock(cu)} remaining`);
			}
		}

		tick() {
			if (!this.visible) return;
			this._renderCache(); // cache countdown is the only per-second update
		}

		// ---- usage details popover ----
		toggleUsagePopover() {
			CT.popover.toggle('usage', () => this._openUsagePopover());
		}
		_openUsagePopover() {
			const anchorRect = this.bar.getBoundingClientRect();
			const map = CT.state.map;
			const usage = CT.state.usage;
			return CT.popover.show({
				title: 'Usage',
				kind: 'usage',
				width: 300,
				anchorRect,
				triggerEl: this.usageBtn,
				build: (body, api) => {
					const row = (name, pct, sub, help) => {
						const lvl = pct == null ? null : CT.usage.level(pct);
						return `<div class="ct-urow">
							<div class="ct-urow__top"><span class="ct-urow__name">${esc(name)}</span>
							<span class="ct-urow__val">${pct == null ? '—' : `${pct.toFixed(pct < 10 ? 1 : 0)}%`}${lvl ? ` <span class="ct-tag ct-lvl-${lvl.key}">${lvl.label}</span>` : ''}</span></div>
							<div class="ct-bar-track"><div class="ct-bar-fill ct-lvlbg-${lvl ? lvl.key : 'healthy'}" style="width:${pct || 0}%"></div></div>
							${sub ? `<div class="ct-hint">${esc(sub)}</div>` : ''}
							<div class="ct-hint ct-hint--help">${esc(help)}</div>
						</div>`;
					};
					const ctxPct = map?.count ? Math.min(100, (map.total / CT.CONST.CONTEXT_LIMIT_TOKENS) * 100) : null;
					const cu = map?.cachedUntil;
					const cacheActive = cu && Date.now() < cu;
					const f = usage?.five_hour, s7 = usage?.seven_day;
					body.innerHTML =
						row('Session (5h)', f?.utilization ?? null, f?.resets_at ? `Resets in ${fmtCountdown(Date.parse(f.resets_at))}` : '', METRIC_HELP.five) +
						row('Weekly (7d)', s7?.utilization ?? null, s7?.resets_at ? `Resets in ${fmtCountdown(Date.parse(s7.resets_at))}` : '', METRIC_HELP.seven) +
						row('Context window', ctxPct, map?.count ? `${CT.tokenizer.isApproximate() ? '~' : ''}${fmtTokens(map.total)} / ${fmtTokens(CT.CONST.CONTEXT_LIMIT_TOKENS)} tokens · ${map.count} messages` : 'Open a conversation', METRIC_HELP.ctx) +
						`<div class="ct-urow"><div class="ct-urow__top"><span class="ct-urow__name">Prompt cache</span><span class="ct-urow__val ct-urow__val--muted">${cacheActive ? fmtClock(cu) + ' left' : 'expired'}</span></div><div class="ct-hint ct-hint--help">${esc(METRIC_HELP.cache)}</div></div>`;
					api.place();
				}
			});
		}

		_hide() {
			this.visible = false;
			this.bar.classList.remove('ct-strip--show');
		}
	}

	CT.BottomBar = BottomBar;
})();
