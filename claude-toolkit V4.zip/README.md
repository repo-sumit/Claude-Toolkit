# Claude Toolkit

A productivity layer for `claude.ai`, bundled into one extension. Everything runs
locally — it reads Claude's *own* API traffic in your browser, stores settings in
local browser storage, and never sends anything anywhere.

## What's inside (v0.4)

**Thin composer telemetry strip** — a slim, single-line status strip that
auto-positions just outside the composer box (below it, flipping above if there's
no room) so it never covers the model selector, effort selector, attachment
button, mic, or send. It shows `Session %` and `Weekly %` with tiny progress
rails and reset times, `Ctx %`, the prompt-cache countdown (only while active),
and a suggested model — plus one ⚡ Tools icon and one ⊞ panel icon. No
always-visible action buttons. It's responsive: full labels at ≥900px wide,
Session/Weekly/Ctx at 640–899px, abbreviated `5h / 7d / Ctx / tier` below 430px.
Click the usage area for a compact **usage details** popover (thin bars,
Healthy/Moderate/High/Near-limit badges, reset timers, brief explanations).

**Chat Map with timestamps** — the Map tab lists every message on the active
branch as a token heatmap; each row now shows the **time it was sent** (the time
after each question and each Claude reply), with the token count kept as a muted
secondary value. Click any row to jump to that message.

**Inline export** — a small **⤓ Export** pill tracks the bottom of the last
message, near Claude's own action row. Click it for Copy as Markdown, Copy last
answer, Copy last code block, Download .md, Print/Save-as-PDF, or "More export
options…" (opens the Export tab).

**Quick Tools** — a registry of 20 local tools (`src/content/tools.js`) that turn
your selection or current draft into a high-quality prompt and insert it. The
launcher (⚡, or `Ctrl/Cmd+Shift+K`) has a search box, a **Popular** section,
category grouping, and full keyboard nav (↑/↓ to highlight, Enter to run, Esc to
close). Tools: Improve Writing, Make Concise, Change Tone, Fix Grammar, Convert
to Email, Convert to Bullets, Extract Action Items, Meeting Notes, Decision Log,
PRD Assistant, Debug Code, Explain Error, Generate Commit Message, Code Review
Checklist, JSON Formatter, Copy Last Answer, Copy Last Code Block, Summarize
Chat, Extract Requirements, Find Open Questions.

**Prompt palette** — type `/` in the composer: categories, search across
name/keyword/body, and a fill-in form for any `{{placeholders}}`. The Prompts tab
adds duplicate, import/export JSON, reset, and five installable packs.

**Side panel** — Overview, Map, Tools, Prompts, Export, Settings.

**Model advisor** — a multi-signal engine (`src/content/model.js`) scores draft
length, context usage, attachments, code, and intent keywords to recommend
Haiku / Sonnet / Opus, returning `{ tier, confidence, reason, signals,
detectedAvailableModelName }`. It confidently picks **Haiku** for lightweight
writing/summarizing, **Sonnet** for balanced product/code/analysis work, and
**Opus** only for genuinely complex, high-stakes tasks. The chip above the
composer shows the tier (reason on hover) with one-click Apply.

## The close-button fix

Popovers now use a **single-active-popover** model: opening one closes any other,
close is synchronous (the DOM is removed immediately — no animation gate), the ×
fires on `mousedown` with propagation stopped, and a capture-phase handler closes
on outside-click or Escape. Re-clicking a trigger toggles its popover. The side
panel becomes non-interactive the instant it starts closing.

## Keyboard shortcuts

- `/` at the start of the composer → prompt palette
- `Ctrl/Cmd+Shift+K` → Quick Tools · `+U` → Overview · `+E` → Export
- `Esc` closes any popover, the palette, or the panel
- Panel tabs: `←`/`→`; tool launcher: `↑`/`↓` + Enter

## Settings

Show bottom strip · Compact labels · Show model suggestion · Show cache countdown
· Inline export button · Quick Tools · Slash palette · Model advisor chip ·
Auto-apply model (experimental) · usage-warning thresholds · Reduce motion · High
contrast. All persist in local browser storage.

## Accessibility

Aria labels on every icon control, `aria-expanded`/`aria-controls` on popover
triggers, `role="dialog"`, focus trap + restoration, Escape + outside-click
close, visible focus rings, level *labels* (never color alone), a polite live
region for toasts, ~22–34px targets, and `prefers-reduced-motion` honored (or
forced via Settings). High-contrast mode strengthens borders/outlines.

## Install (unpacked)

**Chrome / Edge / Brave** — `chrome://extensions` → enable **Developer mode** →
**Load unpacked** → select this folder → open any `claude.ai` chat.

**Firefox** (temporary, until restart) — `about:debugging#/runtime/this-firefox`
→ **Load Temporary Add-on…** → pick `manifest.json`.

## Theming note

Surfaces use the extension's own solid colors; light vs dark is chosen by
**measuring the page's background luminance** at runtime (`.ct-dark`), never by
reusing claude.ai's CSS channel variables — so everything stays opaque and
legible.

## Fragile selectors to monitor

All in `src/content/constants.js → CT.SEL`, tried in order with graceful
fallback: `TURNS` (Map jump targets + inline-export anchor), `COMPOSER` (strip
anchor, draft meter, palette, insertion), `MODEL_TRIGGER` / `MENU_ITEM` (model
Apply + name detection — most fragile; auto-apply is off by default), and
`ATTACHMENT` (a model-suggestion signal only).

## Privacy

All processing is local. No external servers, analytics, tracking, or remote
code. The fetch bridge **reads passively** and never mutates claude.ai requests.
Token counting uses a bundled tokenizer.

## Credits & license

Token counting via [gpt-tokenizer](https://github.com/niieani/gpt-tokenizer)
(MIT — see THIRD_PARTY_NOTICES.md). MIT licensed.
