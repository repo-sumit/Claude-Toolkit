(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});
	if (CT.__started) return;
	CT.__started = true;

	const getConversationId = () => {
		const m = window.location.pathname.match(/\/chat\/([^/?]+)/);
		return m ? m[1] : null;
	};
	const getOrgIdFromCookie = () => {
		try {
			return document.cookie.split('; ').find((r) => r.startsWith('lastActiveOrg='))?.split('=')[1] || null;
		} catch {
			return null;
		}
	};

	// Decide light/dark by MEASURING claude.ai's background luminance, rather
	// than guessing class names. This is what makes the panel theme correctly
	// (and stay opaque) regardless of how claude implements its theme.
	function pageIsDark() {
		const lum = (el) => {
			if (!el) return null;
			const c = getComputedStyle(el).backgroundColor || '';
			const m = c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
			if (!m) return null;
			const a = m[4] === undefined ? 1 : parseFloat(m[4]);
			if (a === 0) return null;
			return (0.299 * +m[1] + 0.587 * +m[2] + 0.114 * +m[3]) / 255;
		};
		let l = lum(document.body);
		if (l == null) l = lum(document.documentElement);
		if (l == null) return window.matchMedia?.('(prefers-color-scheme: dark)').matches || false;
		return l < 0.45;
	}

	let currentConversationId = null;
	let currentOrgId = null;
	let usageState = null;
	let lastUsageMs = 0;
	let usageInFlight = false;

	let panel, settings;

	async function boot() {
		settings = await CT.storage.getSettings();

		panel = new CT.Panel({
			onRefresh: () => refreshConversation(),
			onSettingsChange: async (patch, full) => {
				await CT.storage.saveSettings(patch);
				CT.composer.setSettings(full);
			}
		});
		panel.mount();
		panel.setSettings(settings);

		CT.composer.init(settings);

		applyTheme();
		new MutationObserver(applyTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'style', 'data-theme', 'data-mode'] });

		const bridgeReady = CT.injectBridgeOnce();

		CT.bridge.on('ct:conversation', handleConversation);
		CT.bridge.on('ct:message_limit', (ml) => applyUsage(CT.usage.fromMessageLimit(ml)));
		CT.bridge.on('ct:generation_start', () => {
			/* cache will refresh from the next conversation fetch */
		});

		window.addEventListener('ct:urlchange', onUrlMaybeChanged);
		window.addEventListener('popstate', onUrlMaybeChanged);
		document.addEventListener('click', (e) => {
			if (e.target.closest('button[aria-label="Previous"], button[aria-label="Next"]')) setTimeout(refreshConversation, 600);
		});

		await bridgeReady;
		await refreshConversation();
		if (!usageState) await refreshUsage();

		setInterval(tick, 1000);
	}

	function applyTheme() {
		try {
			panel?.applyDark(pageIsDark());
		} catch {
			/* ignore */
		}
	}

	async function refreshConversation() {
		currentConversationId = getConversationId();
		if (!currentConversationId) {
			panel.setConversation(null);
			panel.setMap({ items: [], total: 0, max: 0, count: 0, cachedUntil: null });
			return;
		}
		const orgId = currentOrgId || getOrgIdFromCookie();
		if (!orgId) return;
		currentOrgId = orgId;
		try {
			await CT.bridge.requestConversation(orgId, currentConversationId);
		} catch {
			/* passive capture may still arrive */
		}
	}

	async function refreshUsage() {
		const orgId = currentOrgId || getOrgIdFromCookie();
		if (!orgId || usageInFlight) return;
		currentOrgId = orgId;
		usageInFlight = true;
		try {
			const raw = await CT.bridge.requestUsage(orgId);
			applyUsage(CT.usage.fromUsageEndpoint(raw));
		} catch {
			/* ignore */
		} finally {
			usageInFlight = false;
		}
	}

	function applyUsage(normalized) {
		if (!normalized) return;
		usageState = normalized;
		lastUsageMs = Date.now();
		panel.setUsage(normalized);
	}

	function handleConversation({ orgId, conversationId, data }) {
		if (orgId) currentOrgId = orgId;
		const expected = getConversationId();
		if (expected && conversationId && conversationId !== expected) return;
		if (!data) return;
		panel.setConversation(data);
		panel.setMap(CT.conversation.computeMap(data));
	}

	let lastPath = window.location.pathname;
	function onUrlMaybeChanged() {
		const p = window.location.pathname;
		if (p === lastPath) return;
		lastPath = p;
		refreshConversation();
	}

	function tick() {
		panel.tick();
		// Refresh usage shortly after a window resets (SSE won't fire at rollover).
		const now = Date.now();
		for (const ms of [panel.usageResetMs.five, panel.usageResetMs.seven]) {
			if (ms && now >= ms && now - ms < 2000) refreshUsage();
		}
		// Hourly safety refresh while the tab is visible.
		if (!document.hidden && now - lastUsageMs > 3600000) refreshUsage();
	}

	boot();
})();
