(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});

	// Transparent, adjustable heuristic. Returns { model, reason }.
	function suggestModel(text) {
		const t = (text || '').trim();
		if (!t) return null;
		const tokens = CT.tokenizer.countTokens(t);
		const hasCode = /```|\bfunction\b|\bclass\b|=>|;\s*$|def |import |SELECT .* FROM/im.test(t);
		const deep = /(step[- ]by[- ]step|prove|derive|analy[sz]e|architecture|design (a|the)|trade-?offs?|optimi[sz]e|refactor|debug|reason through|in depth|comprehensive|rigorous)/i.test(t);
		const quick = /^(what is|who is|when |where |define |translate |how do you say|tldr|tl;dr|summar|rephrase|fix typo|spell)/i.test(t);

		if (quick && tokens < 60) {
			return { model: 'Haiku', reason: 'short and direct — Haiku is fastest' };
		}
		if (hasCode || deep || tokens > 400) {
			const why = hasCode ? 'code / technical depth' : deep ? 'deep reasoning asked for' : 'long, complex prompt';
			return { model: 'Opus', reason: `${why} — Opus is strongest` };
		}
		return { model: 'Sonnet', reason: 'general-purpose — Sonnet balances speed and quality' };
	}

	function pick(selectors) {
		for (const s of selectors) {
			const el = document.querySelector(s);
			if (el) return el;
		}
		return null;
	}

	function waitFor(testFn, timeoutMs = 1500) {
		return new Promise((resolve) => {
			const found = testFn();
			if (found) return resolve(found);
			const obs = new MutationObserver(() => {
				const f = testFn();
				if (f) {
					obs.disconnect();
					resolve(f);
				}
			});
			obs.observe(document.body, { childList: true, subtree: true });
			setTimeout(() => {
				obs.disconnect();
				resolve(testFn() || null);
			}, timeoutMs);
		});
	}

	// Best-effort: open the model menu and click the matching family. This is
	// the most fragile feature (it drives claude.ai's own UI) and is OFF by
	// default. Fails quietly with a toast rather than mis-clicking.
	async function applyModel(modelKey) {
		try {
			const trigger = pick(CT.SEL.MODEL_TRIGGER);
			if (!trigger) return false;
			trigger.click();
			const re = new RegExp(modelKey, 'i');
			const menu = await waitFor(() => {
				const items = [];
				for (const sel of CT.SEL.MENU_ITEM) items.push(...document.querySelectorAll(sel));
				return items.length ? items : null;
			});
			if (!menu) return false;
			const hit = Array.from(menu).find((el) => re.test(el.textContent || ''));
			if (!hit) {
				// close the menu we opened
				document.body.click();
				return false;
			}
			hit.click();
			return true;
		} catch {
			return false;
		}
	}

	let toastEl = null;
	function toast(msg) {
		if (!toastEl) {
			toastEl = document.createElement('div');
			toastEl.className = 'ct-toast ct-root';
			document.body.appendChild(toastEl);
		}
		toastEl.textContent = msg;
		toastEl.classList.add('ct-toast--show');
		clearTimeout(toastEl._t);
		toastEl._t = setTimeout(() => toastEl.classList.remove('ct-toast--show'), 2200);
	}

	CT.model = { suggestModel, applyModel, toast };
})();
