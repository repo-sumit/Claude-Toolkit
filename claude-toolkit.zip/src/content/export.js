(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});

	function safeName(name) {
		const base = (name || 'claude-conversation').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, '-').slice(0, 80);
		return base || 'claude-conversation';
	}

	function buildMarkdown(conversation) {
		const trunk = CT.conversation.buildTrunk(conversation);
		const title = conversation?.name || 'Claude conversation';
		const when = conversation?.created_at ? new Date(conversation.created_at).toLocaleString() : '';
		const lines = [`# ${title}`, when ? `_${when}_` : '', ''];
		for (const msg of trunk) {
			const who = msg?.sender === 'assistant' ? 'Claude' : 'You';
			const body = CT.conversation.readableText(msg);
			if (!body) continue;
			lines.push(`## ${who}`, '', body, '');
		}
		return lines.filter((l, i, a) => !(l === '' && a[i - 1] === '')).join('\n');
	}

	function buildJSON(conversation) {
		return JSON.stringify(conversation, null, 2);
	}

	function download(text, filename, mime) {
		const blob = new Blob([text], { type: mime });
		const url = URL.createObjectURL(blob);
		const a = document.createElement('a');
		a.href = url;
		a.download = filename;
		document.body.appendChild(a);
		a.click();
		a.remove();
		setTimeout(() => URL.revokeObjectURL(url), 4000);
	}

	async function copyMarkdown(conversation) {
		const md = buildMarkdown(conversation);
		try {
			await navigator.clipboard.writeText(md);
			return true;
		} catch {
			return false;
		}
	}

	function downloadMarkdown(conversation) {
		download(buildMarkdown(conversation), `${safeName(conversation?.name)}.md`, 'text/markdown');
	}
	function downloadJSON(conversation) {
		download(buildJSON(conversation), `${safeName(conversation?.name)}.json`, 'application/json');
	}

	const esc = (s) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

	// "PDF" = open a clean print view; the browser's Save-as-PDF does the rest.
	function printView(conversation) {
		const trunk = CT.conversation.buildTrunk(conversation);
		const title = conversation?.name || 'Claude conversation';
		const rows = trunk
			.map((msg) => {
				const who = msg?.sender === 'assistant' ? 'Claude' : 'You';
				const body = CT.conversation.readableText(msg);
				if (!body) return '';
				return `<section class="${who === 'Claude' ? 'a' : 'u'}"><h3>${who}</h3><div class="b">${esc(body).replace(/\n/g, '<br>')}</div></section>`;
			})
			.join('');
		const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>
 body{font:14px/1.6 ui-sans-serif,system-ui,sans-serif;max-width:760px;margin:32px auto;padding:0 16px;color:#1f1e1c;}
 h1{font-size:22px;margin:0 0 4px;} .meta{color:#6b6a66;margin-bottom:24px;}
 section{padding:12px 14px;border-radius:10px;margin:10px 0;}
 section.u{background:#eef4ff;} section.a{background:#f6f5f1;}
 h3{margin:0 0 6px;font-size:12px;letter-spacing:.04em;text-transform:uppercase;color:#6b6a66;}
 .b{white-space:normal;word-wrap:break-word;}
 @media print{ section{break-inside:avoid;} }
</style></head><body>
 <h1>${esc(title)}</h1><div class="meta">Exported from claude.ai · ${trunk.length} messages</div>
 ${rows}
 <script>window.onload=function(){setTimeout(function(){window.print();},300);};<\/script>
</body></html>`;
		const w = window.open('', '_blank');
		if (!w) return false;
		w.document.open();
		w.document.write(html);
		w.document.close();
		return true;
	}

	CT.exporter = { buildMarkdown, copyMarkdown, downloadMarkdown, downloadJSON, printView };
})();
