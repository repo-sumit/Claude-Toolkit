(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});

	const fmtTokens = (n) => (n >= 1000 ? `${(n / 1000).toFixed(n >= 10000 ? 0 : 1)}k` : String(n));
	const heatColor = (ratio) => `hsl(${Math.round((1 - Math.max(0, Math.min(1, ratio))) * 140)}, 70%, 48%)`;
	const escapeHtml = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
	const makeId = () => `p_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

	function fmtCountdown(ms) {
		const d = ms - Date.now();
		if (d <= 0) return '0m';
		const min = Math.round(d / 60000);
		if (min < 60) return `${min}m`;
		const h = Math.floor(min / 60);
		const m = min % 60;
		if (h < 24) return `${h}h ${m}m`;
		return `${Math.floor(h / 24)}d ${h % 24}h`;
	}
	function fmtClock(ms) {
		const d = Math.max(0, ms - Date.now());
		const s = Math.floor(d / 1000);
		return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
	}

	class Panel {
		constructor(cbs = {}) {
			this.onRefresh = cbs.onRefresh || null;
			this.onSettingsChange = cbs.onSettingsChange || null;
			this.lastMap = null;
			this.lastConversation = null;
			this.usage = null;
			this.usageResetMs = { five: null, seven: null };
			this.cachedUntil = null;
			this.settings = CT.DEFAULTS;
			this.open = false;
			this.tab = 'map';
			this.editingId = null;
			this._built = false;
		}

		mount() {
			if (this._built) return;
			this._built = true;

			const toggle = document.createElement('button');
			toggle.className = 'ct-toggle ct-root';
			toggle.title = 'Claude Toolkit';
			toggle.innerHTML = '<span class="ct-toggle__icon">⊞</span><span class="ct-toggle__label">Tools</span>';
			toggle.addEventListener('click', () => this.setOpen(!this.open));

			const panel = document.createElement('aside');
			panel.className = 'ct-panel ct-root';
			panel.innerHTML = `
				<div class="ct-head">
					<div class="ct-title">Claude&nbsp;Toolkit</div>
					<div class="ct-head__actions">
						<button class="ct-iconbtn" data-act="refresh" title="Refresh">⟳</button>
						<button class="ct-iconbtn" data-act="close" title="Close">×</button>
					</div>
				</div>
				<div class="ct-tabs">
					<button class="ct-tab" data-tab="map">Map</button>
					<button class="ct-tab" data-tab="usage">Usage</button>
					<button class="ct-tab" data-tab="export">Export</button>
					<button class="ct-tab" data-tab="prompts">Prompts</button>
					<button class="ct-tab" data-tab="settings">⚙</button>
				</div>
				<div class="ct-body">
					<div class="ct-pane" data-pane="map"></div>
					<div class="ct-pane" data-pane="usage"></div>
					<div class="ct-pane" data-pane="export"></div>
					<div class="ct-pane" data-pane="prompts"></div>
					<div class="ct-pane" data-pane="settings"></div>
				</div>`;

			panel.querySelector('[data-act="close"]').addEventListener('click', () => this.setOpen(false));
			panel.querySelector('[data-act="refresh"]').addEventListener('click', () => this.onRefresh && this.onRefresh());
			panel.querySelectorAll('.ct-tab').forEach((b) => b.addEventListener('click', () => this.setTab(b.dataset.tab)));

			document.body.appendChild(toggle);
			document.body.appendChild(panel);
			this.toggle = toggle;
			this.panel = panel;
			this.panes = {};
			panel.querySelectorAll('.ct-pane').forEach((p) => (this.panes[p.dataset.pane] = p));

			this.setTab('map');
			this.renderExport();
			this.renderUsage();
			this.renderPrompts();
			this.renderSettings();
		}

		setOpen(v) {
			this.open = v;
			this.panel.classList.toggle('ct-panel--open', v);
			this.toggle.classList.toggle('ct-toggle--hidden', v);
		}
		setTab(tab) {
			this.tab = tab;
			this.panel.querySelectorAll('.ct-tab').forEach((b) => b.classList.toggle('ct-tab--active', b.dataset.tab === tab));
			Object.entries(this.panes).forEach(([k, el]) => (el.style.display = k === tab ? '' : 'none'));
		}

		applyDark(isDark) {
			document.querySelectorAll('.ct-root').forEach((el) => el.classList.toggle('ct-dark', isDark));
		}

		// ---- data setters ----
		setConversation(data) {
			this.lastConversation = data;
		}
		setMap(mapData) {
			this.lastMap = mapData;
			this.cachedUntil = mapData?.cachedUntil || null;
			this.renderMap();
			this.renderUsage();
		}
		setUsage(usage) {
			this.usage = usage;
			this.usageResetMs.five = usage?.five_hour?.resets_at ? Date.parse(usage.five_hour.resets_at) : null;
			this.usageResetMs.seven = usage?.seven_day?.resets_at ? Date.parse(usage.seven_day.resets_at) : null;
			this.renderUsage();
		}
		setSettings(settings) {
			this.settings = settings;
			this.renderSettings();
			this.renderPrompts();
		}

		// ---- MAP ----
		renderMap() {
			const pane = this.panes.map;
			const m = this.lastMap;
			if (!m || m.count === 0) {
				pane.innerHTML = `<div class="ct-empty">No conversation loaded yet. Open a chat (or hit ⟳) to map it.</div>`;
				return;
			}
			const approx = CT.tokenizer.isApproximate();
			const pct = Math.min(100, (m.total / CT.CONST.CONTEXT_LIMIT_TOKENS) * 100);
			pane.innerHTML = `
				<div class="ct-meter">
					<div class="ct-meter__row"><span class="ct-meter__text">${approx ? '~' : ''}${fmtTokens(m.total)} / ${fmtTokens(CT.CONST.CONTEXT_LIMIT_TOKENS)} tokens</span><span class="ct-meter__pct">${pct.toFixed(pct < 10 ? 1 : 0)}%</span></div>
					<div class="ct-bar"><div class="ct-bar__fill" style="width:${pct}%;background:${heatColor(m.total / CT.CONST.CONTEXT_LIMIT_TOKENS)}"></div></div>
					<div class="ct-hint">${m.count} messages on this branch${approx ? '  ·  approx. counts' : ''}</div>
				</div>
				<div class="ct-list"></div>`;
			const list = pane.querySelector('.ct-list');
			const frag = document.createDocumentFragment();
			for (const it of m.items) {
				const ratio = m.max > 0 ? it.tokens / m.max : 0;
				const row = document.createElement('button');
				row.className = 'ct-row';
				row.title = `${it.sender === 'assistant' ? 'Claude' : 'You'} · ${it.tokens.toLocaleString()} tokens — click to jump`;
				const bar = document.createElement('div');
				bar.className = 'ct-row__bar';
				bar.style.width = `${Math.max(4, ratio * 100)}%`;
				bar.style.background = heatColor(ratio);
				const dot = document.createElement('span');
				dot.className = `ct-row__dot ct-row__dot--${it.sender}`;
				const label = document.createElement('span');
				label.className = 'ct-row__label';
				label.textContent = it.label;
				const tok = document.createElement('span');
				tok.className = 'ct-row__tokens';
				tok.textContent = fmtTokens(it.tokens);
				row.append(bar, dot, label, tok);
				row.addEventListener('click', () => this.jumpTo(it));
				frag.appendChild(row);
			}
			list.replaceChildren(frag);
		}

		findTurns() {
			for (const sel of CT.SEL.TURNS) {
				const els = Array.from(document.querySelectorAll(sel));
				if (els.length) return els;
			}
			return [];
		}
		jumpTo(item) {
			const turns = this.findTurns();
			let target = null;
			if (turns.length && this.lastMap && turns.length === this.lastMap.count) target = turns[item.index] || null;
			if (!target && item.searchKey) {
				const pool = turns.length ? turns : Array.from(document.querySelectorAll('main p, main li, [data-testid="user-message"], .font-claude-message'));
				for (const el of pool) {
					const t = (el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
					if (t && (t.startsWith(item.searchKey) || t.includes(item.searchKey))) {
						target = el;
						break;
					}
				}
			}
			if (!target) {
				this.panel.classList.add('ct-shake');
				setTimeout(() => this.panel.classList.remove('ct-shake'), 360);
				return;
			}
			target.scrollIntoView({ behavior: 'smooth', block: 'center' });
			target.classList.add('ct-flash');
			setTimeout(() => target.classList.remove('ct-flash'), 1300);
		}

		// ---- USAGE ----
		renderUsage() {
			const pane = this.panes.usage;
			const approx = CT.tokenizer.isApproximate();
			const total = this.lastMap?.total || 0;
			const ctxPct = Math.min(100, (total / CT.CONST.CONTEXT_LIMIT_TOKENS) * 100);

			const bar = (label, w, sub) => `
				<div class="ct-usageblk">
					<div class="ct-meter__row"><span class="ct-meter__text">${label}</span><span class="ct-meter__pct">${w == null ? '—' : `${w.toFixed(w < 10 ? 1 : 0)}%`}</span></div>
					<div class="ct-bar"><div class="ct-bar__fill" style="width:${w || 0}%;background:${heatColor((w || 0) / 100)}"></div></div>
					<div class="ct-hint" data-sub="${sub}"></div>
				</div>`;

			const five = this.usage?.five_hour?.utilization;
			const seven = this.usage?.seven_day?.utilization;

			pane.innerHTML = `
				<div class="ct-usageblk">
					<div class="ct-meter__row"><span class="ct-meter__text">Context window</span><span class="ct-meter__pct">${this.lastMap ? `${ctxPct.toFixed(ctxPct < 10 ? 1 : 0)}%` : '—'}</span></div>
					<div class="ct-bar"><div class="ct-bar__fill" style="width:${ctxPct}%;background:${heatColor(total / CT.CONST.CONTEXT_LIMIT_TOKENS)}"></div></div>
					<div class="ct-hint">${this.lastMap ? `${approx ? '~' : ''}${fmtTokens(total)} / ${fmtTokens(CT.CONST.CONTEXT_LIMIT_TOKENS)} tokens` : 'open a conversation'}</div>
				</div>
				<div class="ct-cacheblk">
					<span class="ct-cacheblk__label">Prompt cache</span>
					<span class="ct-cacheblk__val" data-cache>—</span>
				</div>
				${bar('Session (5h)', five, 'five')}
				${bar('Weekly (7d)', seven, 'seven')}
				<div class="ct-hint ct-usagefoot">Session/weekly from claude.ai's own usage API. Updates as you send messages.</div>`;
			this.tick();
		}

		// ---- EXPORT ----
		renderExport() {
			const pane = this.panes.export;
			pane.innerHTML = `
				<div class="ct-exporthint">Export the current branch of this conversation.</div>
				<div class="ct-btns">
					<button class="ct-btn" data-ex="copy">Copy as Markdown</button>
					<button class="ct-btn" data-ex="md">Download .md</button>
					<button class="ct-btn" data-ex="json">Download .json</button>
					<button class="ct-btn" data-ex="pdf">Open print / PDF view</button>
				</div>
				<div class="ct-exportnote" data-note></div>`;
			const note = pane.querySelector('[data-note]');
			const need = () => {
				if (!this.lastConversation) {
					note.textContent = 'Open a conversation first.';
					return false;
				}
				return true;
			};
			pane.querySelector('[data-ex="copy"]').addEventListener('click', async () => {
				if (!need()) return;
				const ok = await CT.exporter.copyMarkdown(this.lastConversation);
				note.textContent = ok ? 'Copied Markdown to clipboard ✓' : 'Clipboard blocked — try Download .md';
			});
			pane.querySelector('[data-ex="md"]').addEventListener('click', () => {
				if (!need()) return;
				CT.exporter.downloadMarkdown(this.lastConversation);
				note.textContent = 'Markdown downloaded ✓';
			});
			pane.querySelector('[data-ex="json"]').addEventListener('click', () => {
				if (!need()) return;
				CT.exporter.downloadJSON(this.lastConversation);
				note.textContent = 'JSON downloaded ✓';
			});
			pane.querySelector('[data-ex="pdf"]').addEventListener('click', () => {
				if (!need()) return;
				const ok = CT.exporter.printView(this.lastConversation);
				note.textContent = ok ? 'Opened print view — choose "Save as PDF"' : 'Popup blocked — allow popups for claude.ai';
			});
		}

		// ---- PROMPTS ----
		renderPrompts() {
			const pane = this.panes.prompts;
			const prompts = this.settings?.prompts || [];
			const rows = prompts
				.map(
					(p) => `
					<div class="ct-prompt" data-id="${p.id}">
						<div class="ct-prompt__main">
							<span class="ct-prompt__name">${escapeHtml(p.name)}</span>
							<span class="ct-prompt__kw">/${escapeHtml(p.keyword || '')}</span>
						</div>
						<div class="ct-prompt__actions">
							<button class="ct-iconbtn" data-edit="${p.id}" title="Edit">✎</button>
							<button class="ct-iconbtn" data-del="${p.id}" title="Delete">🗑</button>
						</div>
					</div>`
				)
				.join('');
			pane.innerHTML = `
				<div class="ct-hint">Type <b>/</b> in the message box to insert these. Use <code>{{name}}</code> for fill-in blanks.</div>
				<div class="ct-prompts">${rows || '<div class="ct-empty">No prompts yet.</div>'}</div>
				<div class="ct-form">
					<div class="ct-form__title" data-formtitle>Add a prompt</div>
					<input class="ct-input" data-f="name" placeholder="Name (e.g. Summarize)">
					<input class="ct-input" data-f="keyword" placeholder="Shortcut keyword (e.g. sum)">
					<textarea class="ct-textarea" data-f="body" rows="4" placeholder="Prompt text. Use {{placeholders}} for blanks."></textarea>
					<div class="ct-form__btns">
						<button class="ct-btn ct-btn--primary" data-save>Save</button>
						<button class="ct-btn" data-cancel style="display:none">Cancel</button>
					</div>
				</div>`;

			pane.querySelectorAll('[data-edit]').forEach((b) =>
				b.addEventListener('click', () => this._startEdit(b.getAttribute('data-edit')))
			);
			pane.querySelectorAll('[data-del]').forEach((b) =>
				b.addEventListener('click', () => this._deletePrompt(b.getAttribute('data-del')))
			);
			pane.querySelector('[data-save]').addEventListener('click', () => this._savePrompt());
			pane.querySelector('[data-cancel]').addEventListener('click', () => this._resetForm());
		}

		_formInputs() {
			const pane = this.panes.prompts;
			return {
				name: pane.querySelector('[data-f="name"]'),
				keyword: pane.querySelector('[data-f="keyword"]'),
				body: pane.querySelector('[data-f="body"]'),
				title: pane.querySelector('[data-formtitle]'),
				cancel: pane.querySelector('[data-cancel]')
			};
		}
		_startEdit(id) {
			const p = (this.settings.prompts || []).find((x) => x.id === id);
			if (!p) return;
			this.editingId = id;
			const f = this._formInputs();
			f.name.value = p.name || '';
			f.keyword.value = p.keyword || '';
			f.body.value = p.body || '';
			f.title.textContent = 'Edit prompt';
			f.cancel.style.display = '';
			this.setTab('prompts');
			f.name.focus();
		}
		_resetForm() {
			this.editingId = null;
			this.renderPrompts();
		}
		_savePrompt() {
			const f = this._formInputs();
			const name = f.name.value.trim();
			const keyword = f.keyword.value.trim().replace(/\s+/g, '');
			const body = f.body.value;
			if (!name || !body.trim()) return;
			const prompts = [...(this.settings.prompts || [])];
			if (this.editingId) {
				const i = prompts.findIndex((x) => x.id === this.editingId);
				if (i >= 0) prompts[i] = { ...prompts[i], name, keyword, body };
			} else {
				prompts.push({ id: makeId(), name, keyword, body });
			}
			this.editingId = null;
			this._commitSettings({ prompts });
		}
		_deletePrompt(id) {
			const prompts = (this.settings.prompts || []).filter((x) => x.id !== id);
			this._commitSettings({ prompts });
		}

		// ---- SETTINGS ----
		renderSettings() {
			const pane = this.panes.settings;
			const s = this.settings || {};
			const toggle = (key, label, sub) => `
				<label class="ct-setting">
					<span><span class="ct-setting__label">${label}</span>${sub ? `<span class="ct-setting__sub">${sub}</span>` : ''}</span>
					<input type="checkbox" data-set="${key}" ${s[key] ? 'checked' : ''}>
				</label>`;
			pane.innerHTML = `
				${toggle('enablePalette', 'Slash-command prompt palette', 'Type / in the composer to insert prompts')}
				${toggle('showAdvisor', 'Model advisor chip', 'Live token meter + suggested model on the composer')}
				${toggle('autoApplyModel', 'Auto-apply suggested model', 'Experimental — drives the claude.ai model picker')}
				<div class="ct-hint ct-settingsfoot">Settings + prompts are stored locally in your browser. Nothing leaves the page.</div>`;
			pane.querySelectorAll('[data-set]').forEach((cb) =>
				cb.addEventListener('change', () => this._commitSettings({ [cb.getAttribute('data-set')]: cb.checked }))
			);
		}

		_commitSettings(patch) {
			this.settings = { ...this.settings, ...patch };
			if (this.onSettingsChange) this.onSettingsChange(patch, this.settings);
			this.renderSettings();
			this.renderPrompts();
		}

		// ---- per-second updates ----
		tick() {
			const pane = this.panes.usage;
			if (!pane) return;
			const cacheEl = pane.querySelector('[data-cache]');
			if (cacheEl) {
				if (!this.cachedUntil) cacheEl.textContent = '—';
				else if (Date.now() >= this.cachedUntil) cacheEl.textContent = 'expired';
				else cacheEl.textContent = `${fmtClock(this.cachedUntil)} left`;
			}
			const setSub = (which, ms) => {
				const el = pane.querySelector(`[data-sub="${which}"]`);
				if (el) el.textContent = ms ? `resets in ${fmtCountdown(ms)}` : '';
			};
			setSub('five', this.usageResetMs.five);
			setSub('seven', this.usageResetMs.seven);
		}
	}

	CT.Panel = Panel;
})();
