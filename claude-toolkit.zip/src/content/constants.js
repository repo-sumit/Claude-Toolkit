(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});

	CT.CONST = Object.freeze({
		CONTEXT_LIMIT_TOKENS: 200000,
		CACHE_WINDOW_MS: 5 * 60 * 1000,
		BRIDGE_SCRIPT_ID: 'ct-bridge-script',
		MARKER: 'ClaudeToolkit',
		STORAGE_KEY: 'claudeToolkit.v1'
	});

	// ---- Selectors most likely to drift on a claude.ai redesign --------------
	// If a feature that touches the page (jump, prompt insert, model apply, the
	// live draft meter) stops working, these are the knobs to turn. Each is a
	// list tried in order; features fall back gracefully when all are stale.
	CT.SEL = Object.freeze({
		// Rendered message turns, used by Chat Map's jump-to-message.
		TURNS: [
			'[data-testid="user-message"], .font-claude-message',
			'div[data-test-render-count] .font-claude-message, div[data-test-render-count] [data-testid="user-message"]',
			'div[data-test-render-count]'
		],
		// The composer is a ProseMirror contenteditable; we pick the visible one
		// nearest the bottom of the screen at runtime.
		COMPOSER: ['div[contenteditable="true"].ProseMirror', 'div[contenteditable="true"]'],
		// The clickable element that opens the model picker.
		MODEL_TRIGGER: [
			'[data-testid="model-selector-dropdown"]',
			'button[aria-haspopup="menu"][data-testid*="model"]',
			'button[aria-haspopup="listbox"]'
		],
		// Items inside the open model menu.
		MENU_ITEM: ['[role="menuitem"]', '[role="option"]']
	});

	// Model families the advisor can recommend. Order = capability tier.
	CT.MODELS = Object.freeze([
		{ key: 'Haiku', label: 'Haiku', blurb: 'fastest, cheapest' },
		{ key: 'Sonnet', label: 'Sonnet', blurb: 'balanced default' },
		{ key: 'Opus', label: 'Opus', blurb: 'most capable' }
	]);

	CT.DEFAULTS = Object.freeze({
		enablePalette: true,
		showAdvisor: true,
		autoApplyModel: false,
		panelSide: 'right',
		prompts: [
			{ id: 'p_sum', name: 'Summarize', keyword: 'sum', body: 'Summarize the following in {{n}} concise bullet points:\n\n{{text}}' },
			{ id: 'p_eli5', name: 'Explain simply', keyword: 'eli5', body: 'Explain {{topic}} simply, as if to a smart 12-year-old. Use one everyday analogy.' },
			{ id: 'p_improve', name: 'Improve writing', keyword: 'improve', body: 'Improve the clarity and flow of the text below without changing its meaning. Return only the rewrite.\n\n{{text}}' },
			{ id: 'p_debug', name: 'Debug code', keyword: 'debug', body: 'Here is code that is misbehaving. Find the bug, explain the root cause, and give a corrected version.\n\n```\n{{code}}\n```' }
		]
	});
})();
