# Claude Toolkit

A single browser extension that bundles five tools for `claude.ai` into one
slide-in panel plus a couple of composer helpers. Everything runs locally — it
reads Claude's *own* API traffic in your browser and never sends anything out.

## What's inside

**1. Chat Map** — a token heatmap + jump navigator. Every message on the current
branch is a row, with a bar (green → red) sized to how much context it eats and a
running total against the 200k limit. Click a row to scroll to that message with a
highlight flash.

**2. Usage / cache / token counter** — the "Usage" tab shows your context-window
fill, the 5-minute prompt-cache countdown, and your Session (5h) and Weekly (7d)
usage bars with reset timers, pulled from claude.ai's usage API.

**3. One-click export** — copy the conversation as Markdown, download `.md` or
`.json`, or open a clean print view to save as PDF.

**4. Prompt palette** — save reusable prompt templates and insert them by typing
`/` in the message box (arrow keys + Enter to pick). Templates support
`{{placeholders}}` for fill-in blanks. Manage them in the "Prompts" tab.

**5. Model advisor** — as you type, a small chip on the composer shows your draft's
token count and suggests a model (Haiku / Sonnet / Opus) based on length and
complexity, with one-click **Apply**. An optional, experimental setting can
auto-switch the model for you.

## Install (unpacked)

**Chrome / Edge / Brave**
1. Go to `chrome://extensions`, enable **Developer mode** (top right).
2. **Load unpacked** → select this folder.
3. Open any `claude.ai` conversation — a **Tools** tab appears on the right edge.

**Firefox** (temporary, until restart)
1. `about:debugging#/runtime/this-firefox` → **Load Temporary Add-on…**
2. Pick `manifest.json` in this folder.

## About the transparency fix

An earlier version themed the panel with claude.ai's CSS variables
(`var(--bg-100)`). Those hold raw Tailwind color *channels* (meant for
`hsl(var(--bg-100))`), so used directly as a color they're invalid and the browser
drops the background — leaving the panel see-through. This version uses its own
solid colors and decides light vs dark by **measuring the page's background
luminance** at runtime, so every surface is opaque and themed correctly no matter
how claude implements its theme.

## Knobs you may need to tweak

Three features touch claude.ai's live DOM, which can change on a redesign. If one
stops working, the selectors are all collected in **`src/content/constants.js`**
under `CT.SEL`:

- **`TURNS`** — used by Chat Map's jump-to-message. Falls back to text-matching, so
  jumps keep working even if these go stale; a correct selector just makes them exact.
- **`COMPOSER`** — the message box, used by the prompt palette and the live meter.
- **`MODEL_TRIGGER` / `MENU_ITEM`** — used only by the model **Apply** / auto-apply.
  This is the most fragile feature (it drives claude.ai's own picker) and
  auto-apply is **off by default**. It fails quietly with a toast rather than
  mis-clicking.

The model heuristic itself lives in `src/content/model.js` (`suggestModel`) and is
easy to adjust.

## Privacy

All processing is local; no external servers, no tracking. The extension reads the
`lastActiveOrg` cookie only to ask claude.ai for your current conversation and
usage, and talks only to `claude.ai`. Token counting uses a bundled tokenizer.

## Credits & license

- Token counting via [gpt-tokenizer](https://github.com/niieani/gpt-tokenizer) (MIT).
- Architecture inspired by the Claude Counter extension.
- MIT licensed.
