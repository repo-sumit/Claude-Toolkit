(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});
	const stack = [];

	function clamp(v, lo, hi) {
		return Math.max(lo, Math.min(hi, v));
	}

	// show({ title, build(bodyEl, api), anchorRect?, width?, modal? }) -> close()
	// - anchorRect: position near it (above if room, else below); else centered.
	// - modal: dim backdrop, click-outside closes.
	// Escape always closes the top popover. Focus is trapped and restored.
	function show(opts = {}) {
		const prevFocus = document.activeElement;

		let backdrop = null;
		if (opts.modal) {
			backdrop = document.createElement('div');
			backdrop.className = 'ct-backdrop';
			CT.a11y.decorate(backdrop);
			backdrop.addEventListener('mousedown', (e) => {
				if (e.target === backdrop) close();
			});
			document.body.appendChild(backdrop);
		}

		const pop = document.createElement('div');
		pop.className = 'ct-popover';
		pop.setAttribute('role', 'dialog');
		pop.setAttribute('aria-modal', opts.modal ? 'true' : 'false');
		if (opts.title) pop.setAttribute('aria-label', opts.title);
		CT.a11y.decorate(pop);
		if (opts.width) pop.style.width = `${opts.width}px`;

		const head = document.createElement('div');
		head.className = 'ct-popover__head';
		head.innerHTML = `<span class="ct-popover__title">${CT.u.esc(opts.title || '')}</span>`;
		const x = document.createElement('button');
		x.className = 'ct-iconbtn';
		x.setAttribute('aria-label', 'Close');
		x.textContent = '×';
		x.addEventListener('click', () => close());
		head.appendChild(x);
		pop.appendChild(head);

		const body = document.createElement('div');
		body.className = 'ct-popover__body';
		pop.appendChild(body);
		document.body.appendChild(pop);

		// Position after it has a size.
		const place = () => {
			const r = pop.getBoundingClientRect();
			if (opts.anchorRect) {
				const a = opts.anchorRect;
				let left = clamp(a.left + a.width / 2 - r.width / 2, 8, window.innerWidth - r.width - 8);
				let top = a.top - r.height - 8;
				if (top < 8) top = clamp(a.bottom + 8, 8, window.innerHeight - r.height - 8);
				pop.style.left = `${left}px`;
				pop.style.top = `${top}px`;
			} else {
				pop.style.left = `${clamp((window.innerWidth - r.width) / 2, 8, window.innerWidth - 8)}px`;
				pop.style.top = `${clamp((window.innerHeight - r.height) / 2.4, 8, window.innerHeight - r.height - 8)}px`;
			}
		};

		const releaseTrap = CT.a11y.trapFocus(pop);
		const entry = { pop, close };
		stack.push(entry);

		let closed = false;
		function close(result) {
			if (closed) return;
			closed = true;
			releaseTrap();
			const i = stack.indexOf(entry);
			if (i >= 0) stack.splice(i, 1);
			pop.remove();
			backdrop?.remove();
			if (prevFocus && document.contains(prevFocus)) prevFocus.focus();
			if (typeof opts.onClose === 'function') opts.onClose(result);
		}

		if (typeof opts.build === 'function') opts.build(body, { close, place });
		place();
		const f = CT.a11y.focusables(body)[0] || x;
		f.focus();

		return close;
	}

	// One global Escape handler closes the top-most popover.
	document.addEventListener(
		'keydown',
		(e) => {
			if (e.key !== 'Escape' || !stack.length) return;
			e.preventDefault();
			e.stopPropagation();
			stack[stack.length - 1].close(null);
		},
		true
	);

	// ---- Placeholder filling --------------------------------------------------
	// Parses unique {{placeholder names}} from a template (pure; testable).
	function parsePlaceholders(template) {
		const names = [];
		const re = /\{\{([^{}]+?)\}\}/g;
		let m;
		while ((m = re.exec(template || ''))) {
			const name = m[1].trim();
			if (name && !names.includes(name)) names.push(name);
		}
		return names;
	}

	function applyValues(template, values) {
		return (template || '').replace(/\{\{([^{}]+?)\}\}/g, (_, raw) => {
			const k = raw.trim();
			return values[k] !== undefined && values[k] !== '' ? values[k] : `{{${k}}}`;
		});
	}

	// fillPlaceholders(template, choices?) -> Promise<string|null>
	// choices: { placeholderName: ['option a', 'option b'] } renders a select.
	function fillPlaceholders(template, choices = {}) {
		const names = parsePlaceholders(template);
		if (!names.length) return Promise.resolve(template);

		return new Promise((resolve) => {
			show({
				title: 'Fill in the blanks',
				modal: true,
				width: 340,
				onClose: (r) => resolve(r ?? null),
				build: (body, api) => {
					const form = document.createElement('div');
					form.className = 'ct-fillform';
					const fields = {};
					for (const name of names) {
						const row = document.createElement('label');
						row.className = 'ct-fillform__row';
						const cap = document.createElement('span');
						cap.className = 'ct-fillform__label';
						cap.textContent = name;
						row.appendChild(cap);
						let input;
						if (Array.isArray(choices[name]) && choices[name].length) {
							input = document.createElement('select');
							input.className = 'ct-input';
							for (const opt of choices[name]) {
								const o = document.createElement('option');
								o.value = o.textContent = opt;
								input.appendChild(o);
							}
						} else if (/text|code|data|notes|content/i.test(name)) {
							input = document.createElement('textarea');
							input.className = 'ct-textarea';
							input.rows = 3;
						} else {
							input = document.createElement('input');
							input.className = 'ct-input';
							input.type = 'text';
						}
						input.setAttribute('aria-label', name);
						fields[name] = input;
						row.appendChild(input);
						form.appendChild(row);
					}
					const btns = document.createElement('div');
					btns.className = 'ct-form__btns';
					const ok = document.createElement('button');
					ok.className = 'ct-btn ct-btn--primary';
					ok.textContent = 'Insert';
					const cancel = document.createElement('button');
					cancel.className = 'ct-btn';
					cancel.textContent = 'Cancel';
					btns.append(ok, cancel);
					form.appendChild(btns);
					body.appendChild(form);

					const submit = () => {
						const values = {};
						for (const [k, el] of Object.entries(fields)) values[k] = el.value;
						api.close(applyValues(template, values));
					};
					ok.addEventListener('click', submit);
					cancel.addEventListener('click', () => api.close(null));
					form.addEventListener('keydown', (e) => {
						if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
							e.preventDefault();
							submit();
						}
					});
					api.place();
				}
			});
		});
	}

	CT.popover = { show, fillPlaceholders, parsePlaceholders, applyValues, _stack: stack };
})();
