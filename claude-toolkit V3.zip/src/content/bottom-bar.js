(() => {
	'use strict';

	const CT = (globalThis.ClaudeToolkit = globalThis.ClaudeToolkit || {});
	const { fmtTokens, fmtClock, fmtCountdown, esc } = CT.u;

	const METRIC_HELP = {
		draft: 'Tokens in your current draft (live, counted locally).',
		ctx: 'How full this conversation\u2019s 200k context window is. Older content costs quality and speed as this fills.',
		cache: 'Claude caches your conversation for ~5 minutes after each reply. Sending within the window is faster/cheaper.',
		five: 'Your rolling 5-hour session usage, from claude.ai\u2019s own usage API.',
		seven: 'Your rolling 7-day usage, from claude.ai\u2019s own usage API.'
	};

	class BottomBar {
		constructor({ onOpenPanel } = {}) {
			this.onOpenPanel = onOpenPanel || (() => {});
			this.settings = CT.DEFAULTS;
			this.expanded = false;
			this.visible = false;
			this._built = false;
		}

		mount(settings) {
			if (this._built) return;
			this._built = true;
			this.settings = settings;
			this.expanded = !settings.bottomBarCompact;

			const bar = document.createElement('div');
			bar.className = 'ct-bar';
			bar.setAttribute('role', 'toolbar');
			bar.setAttribute('aria-label', 'Claude Toolkit status bar');
			CT.a11y.decorate(bar);
			bar.innerHTML = `
				<div class="ct-bar__main">
					<span class="ct-pill ct-pill--static" data-m="draft" title="${esc(METRIC_HELP.draft)}"><span class="ct-pill__k">Draft</span><span class="ct-pill__v" data-v="draft">—</span></span>
					<button class="ct-pill" data-m="ctx" title="${esc(METRIC_HELP.ctx)}"><span class="ct-pill__k">Ctx</span><span class="ct-pill__v" data-v="ctx">—</span></button>
					<button class="ct-pill" data-m="five" title="${esc(METRIC_HELP.five)}"><span class="ct-pill__k">5h</span><span class="ct-pill__v" data-v="five">—</span></button>
					<button class="ct-pill" data-m="cache" title="${esc(METRIC_HELP.cache)}"><span class="ct-pill__k">Cache</span><span class="ct-pill__v" data-v="cache">—</span></button>
					<span class="ct-bar__warn" data-warn role="status"></span>
					<span class="ct-bar__spacer"></span>
					<button class="ct-iconbtn ct-bar__btn" data-act="tools" title="Quick Tools (Ctrl/Cmd+Shift+K)" aria-label="Open Quick Tools">⚡<span class="ct-bar__btntext">Tools</span></button>
					<button class="ct-iconbtn ct-bar__btn" data-act="expand" aria-label="Show more metrics" aria-expanded="false" title="More">▾</button>
					<button class="ct-iconbtn ct-bar__btn" data-act="panel" title="Open Toolkit panel" aria-label="Open Claude Toolkit panel">⊞</button>
				</div>
				<div class="ct-bar__more" hidden>
					<button class="ct-pill" data-m="seven" title="${esc(METRIC_HELP.seven)}"><span class="ct-pill__k">7d</span><span class="ct-pill__v" data-v="seven">—</span></button>
					<span class="ct-pill ct-pill--static" data-m="model"><span class="ct-pill__k">Suggested</span><span class="ct-pill__v" data-v="model">—</span></span>
					<button class="ct-minibtn" data-act="applymodel" aria-label="Apply suggested model">Apply</button>
					<span class="ct-bar__spacer"></span>
					<button class="ct-minibtn" data-qt="t_improve">Improve</button>
					<button class="ct-minibtn" data-qt="t_bullets">Bullets</button>
					<button class="ct-minibtn" data-qt="t_actions">Actions</button>
					<button class="ct-minibtn" data-qt="t_copy_answer">Copy answer</button>
				</div>`;
			document.body.appendChild(bar);
			this.bar = bar;

			// Wiring
			bar.querySelector('[data-act="panel"]').addEventListener('click', () => this.onOpenPanel());
			bar.querySelector('[data-act="tools"]').addEventListener('click', (e) => {
				CT.tools.openLauncher(e.currentTarget.getBoundingClientRect());
			});
			const expandBtn = bar.querySelector('[data-act="expand"]');
			expandBtn.addEventListener('click', () => this.setExpanded(!this.expanded));
			bar.querySelector('[data-act="applymodel"]').addEventListener('click', async () => {
				const sug = this._suggestion;
				if (!sug) return CT.model.toast('Type a draft first');
				const ok = await CT.model.applyModel(sug.model);
				CT.model.toast(ok ? `Switched to ${sug.model}` : `Couldn't switch automatically — pick ${sug.model} manually`);
			});
			bar.querySelectorAll('[data-qt]').forEach((b) => b.addEventListener('click', () => CT.tools.run(b.getAttribute('data-qt'))));
			for (const m of ['ctx', 'five', 'cache', 'seven']) {
				const el = bar.querySelector(`[data-m="${m}"]`);
				if (el?.tagName === 'BUTTON') el.addEventListener('click', () => this.openUsagePopover());
			}

			this.setExpanded(this.expanded, true);

			// Live draft tokens on composer input.
			document.addEventListener(
				'input',
				(e) => {
					const ed = CT.getComposer();
					if (ed && (e.target === ed || ed.contains(e.target))) this._updateDraft();
				},
				true
			);

			// Positioning loop: light interval + resize/scroll, not a rAF loop.
			this._posT = setInterval(() => this._position(), 350);
			window.addEventListener('resize', () => this._position());
			window.addEventListener('scroll', () => this._position(), true);
			this._position();
			this.render();
		}

		setSettings(s) {
			this.settings = s;
			if (!s.showBottomBar) this._hide();
			else this._position();
			this.render();
		}

		setExpanded(v, silent) {
			this.expanded = v;
			const more = this.bar.querySelector('.ct-bar__more');
			more.hidden = !v;
			const btn = this.bar.querySelector('[data-act="expand"]');
			btn.setAttribute('aria-expanded', v ? 'true' : 'false');
			btn.setAttribute('aria-label', v ? 'Show fewer metrics' : 'Show more metrics');
			btn.textContent = v ? '▴' : '▾';
			if (!silent) this._position();
		}

		_hide() {
			this.visible = false;
			this.bar.classList.remove('ct-bar--show');
		}

		_position() {
			if (!this.settings?.showBottomBar) return this._hide();
			const ed = CT.getComposer();
			if (!ed) return this._hide();
			const r = ed.getBoundingClientRect();
			if (r.width < 120) return this._hide();

			const width = Math.min(760, Math.max(300, r.width));
			this.bar.style.width = `${width}px`;
			this.bar.style.left = `${Math.max(8, r.left + (r.width - width) / 2)}px`;

			const h = this.bar.offsetHeight || 34;
			// Prefer below the composer; flip above if there isn't room.
			let top = r.bottom + 8;
			if (top + h > window.innerHeight - 6) top = r.top - h - 8;
			if (top < 6) return this._hide();
			this.bar.style.top = `${top}px`;

			if (!this.visible) {
				this.visible = true;
				this.bar.classList.add('ct-bar--show');
			}
		}

		_updateDraft() {
			const ed = CT.getComposer();
			const text = ed ? (ed.textContent || '').trim() : '';
			const tokens = text ? CT.tokenizer.countTokens(text) : 0;
			this._set('draft', tokens ? `≈${fmtTokens(tokens)} tok` : '—');
			this._suggestion = text ? CT.model.suggestModel(text) : null;
			const mEl = this.bar.querySelector('[data-v="model"]');
			if (mEl) {
				mEl.textContent = this._suggestion ? this._suggestion.model : '—';
				mEl.parentElement.title = this._suggestion ? this._suggestion.reason : '';
			}
		}

		_set(key, text, levelKey) {
			const el = this.bar.querySelector(`[data-v="${key}"]`);
			if (!el) return;
			el.textContent = text;
			const pill = el.closest('.ct-pill');
			pill.classList.remove('ct-lvl-healthy', 'ct-lvl-moderate', 'ct-lvl-high', 'ct-lvl-critical');
			if (levelKey) pill.classList.add(`ct-lvl-${levelKey}`);
		}

		// Called every second by main.js and whenever state changes.
		render() {
			if (!this._built) return;
			const map = CT.state.map;
			const usage = CT.state.usage;

			// Context
			let ctxPct = null;
			if (map && map.count) {
				ctxPct = Math.min(100, (map.total / CT.CONST.CONTEXT_LIMIT_TOKENS) * 100);
				const lvl = CT.usage.level(ctxPct);
				this._set('ctx', `${ctxPct.toFixed(ctxPct < 10 ? 1 : 0)}%`, lvl?.key);
				const pill = this.bar.querySelector('[data-m="ctx"]');
				pill.setAttribute('aria-label', `Context window ${Math.round(ctxPct)} percent, ${lvl.label}`);
			} else this._set('ctx', '—');

			// 5h / 7d
			const setUsage = (key, w, name) => {
				const pct = w?.utilization;
				if (pct == null) return this._set(key, '—');
				const lvl = CT.usage.level(pct);
				this._set(key, `${pct.toFixed(pct < 10 ? 1 : 0)}%`, lvl?.key);
				const pill = this.bar.querySelector(`[data-m="${key}"]`);
				const resets = w.resets_at ? `, resets in ${fmtCountdown(Date.parse(w.resets_at))}` : '';
				pill.setAttribute('aria-label', `${name} ${Math.round(pct)} percent, ${lvl.label}${resets}`);
			};
			setUsage('five', usage?.five_hour, 'Session usage');
			setUsage('seven', usage?.seven_day, 'Weekly usage');

			// Cache
			const cu = map?.cachedUntil;
			if (!cu) this._set('cache', '—');
			else if (Date.now() >= cu) this._set('cache', 'expired', 'moderate');
			else this._set('cache', fmtClock(cu));

			// Compact warning text (worst offender wins)
			const warnEl = this.bar.querySelector('[data-warn]');
			const worst = [];
			if (ctxPct != null && ctxPct >= 85) worst.push([ctxPct, ctxPct >= 95 ? 'Context near limit' : 'Context high']);
			const f = usage?.five_hour?.utilization;
			if (f != null && f >= 85) worst.push([f, f >= 95 ? '5h near limit' : '5h high']);
			const s7 = usage?.seven_day?.utilization;
			if (s7 != null && s7 >= 85) worst.push([s7, s7 >= 95 ? '7d near limit' : '7d high']);
			if (cu && Date.now() >= cu && Date.now() - cu < 10 * 60 * 1000) worst.push([0, 'Cache expired']);
			if (worst.length && this.settings.usageWarnings !== false) {
				worst.sort((a, b) => b[0] - a[0]);
				warnEl.textContent = worst[0][1];
				warnEl.classList.add('ct-bar__warn--on');
			} else {
				warnEl.textContent = '';
				warnEl.classList.remove('ct-bar__warn--on');
			}

			this._updateDraft();
		}

		tick() {
			if (!this.visible) return;
			// Only the cache clock needs per-second updates.
			const cu = CT.state.map?.cachedUntil;
			if (cu) {
				if (Date.now() >= cu) this._set('cache', 'expired', 'moderate');
				else this._set('cache', fmtClock(cu));
			}
		}

		openUsagePopover() {
			const anchorRect = this.bar.getBoundingClientRect();
			const map = CT.state.map;
			const usage = CT.state.usage;
			CT.popover.show({
				title: 'Usage details',
				anchorRect,
				width: 320,
				build: (body, api) => {
					const row = (name, pct, sub, help) => {
						const lvl = pct == null ? null : CT.usage.level(pct);
						return `<div class="ct-urow">
							<div class="ct-urow__top"><span class="ct-urow__name">${esc(name)}</span>
							<span class="ct-urow__val">${pct == null ? '—' : `${pct.toFixed(pct < 10 ? 1 : 0)}%`}${lvl ? ` <span class="ct-tag ct-lvl-${lvl.key}">${lvl.label}</span>` : ''}</span></div>
							<div class="ct-bar-track"><div class="ct-bar-fill ct-lvlbg-${lvl ? lvl.key : 'healthy'}" style="width:${pct || 0}%"></div></div>
							<div class="ct-hint">${esc(sub || '')}</div>
							<div class="ct-hint ct-hint--help">${esc(help)}</div>
						</div>`;
					};
					const ctxPct = map?.count ? Math.min(100, (map.total / CT.CONST.CONTEXT_LIMIT_TOKENS) * 100) : null;
					const cu = map?.cachedUntil;
					const cacheSub = !cu ? 'No reply yet' : Date.now() >= cu ? 'Expired' : `${fmtClock(cu)} left`;
					const f = usage?.five_hour, s7 = usage?.seven_day;
					body.innerHTML =
						row('Context window', ctxPct, map?.count ? `${CT.tokenizer.isApproximate() ? '~' : ''}${fmtTokens(map.total)} / ${fmtTokens(CT.CONST.CONTEXT_LIMIT_TOKENS)} tokens · ${map.count} messages` : 'Open a conversation', METRIC_HELP.ctx) +
						`<div class="ct-urow"><div class="ct-urow__top"><span class="ct-urow__name">Prompt cache</span><span class="ct-urow__val">${esc(cacheSub)}</span></div><div class="ct-hint ct-hint--help">${esc(METRIC_HELP.cache)}</div></div>` +
						row('Session (5h)', f?.utilization ?? null, f?.resets_at ? `Resets in ${fmtCountdown(Date.parse(f.resets_at))}` : '', METRIC_HELP.five) +
						row('Weekly (7d)', s7?.utilization ?? null, s7?.resets_at ? `Resets in ${fmtCountdown(Date.parse(s7.resets_at))}` : '', METRIC_HELP.seven);
					api.place();
				}
			});
		}
	}

	CT.BottomBar = BottomBar;
})();
