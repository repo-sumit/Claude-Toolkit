# Claude Toolkit

A productivity layer for `claude.ai`, bundled into one extension. Everything runs
locally — it reads Claude's *own* API traffic in your browser, stores settings in
local browser storage, and never sends anything anywhere.

## What's inside (v0.3)

**Bottom status bar** — a thin, always-visible strip that auto-positions itself
just below the composer (flips above if there's no room): live draft token count,
`Ctx %`, `5h %`, prompt-cache countdown, and compact warnings like `5h high` or
`Cache expired`. Expand it (▾) for `7d %`, the suggested model with one-click
Apply, and four favorite quick tools. Click any usage pill for a **usage details**
popover with bars, Healthy/Moderate/High/Near-limit labels, reset timers, and
plain-English explanations of each metric. Toggle the bar in Settings.

**Quick Tools** — a registry of 20 local tools (`src/content/tools.js`) that turn
your selection or current draft into a high-quality prompt and insert it:

- *Writing:* Improve Writing, Make Concise, Change Tone (5 tones), Fix Grammar, Convert to Email, Convert to Bullets
- *Productivity:* Extract Action Items, Meeting Notes Formatter, Decision Log, PRD Assistant
- *Developer:* Debug Code, Explain Error, Generate Commit Message, Code Review Checklist, JSON Formatter
- *Conversation:* Copy Last Claude Answer, Copy Last Code Block, Summarize Current Chat, Extract Requirements, Find Open Questions

Open from the bar's ⚡ Tools button, the panel's Tools tab, or `Ctrl/Cmd+Shift+K`.
Adding your own tool is one `CT.tools.register({...})` call.

**Prompt palette** — type `/` in the composer. Now with categories, search across
name/keyword/body/category, and a fill-in form whenever a prompt contains
`{{placeholders}}`. The Prompts tab adds duplicate, import/export as JSON, reset
to defaults, and five installable packs (Writing, Product Management,
Engineering, Data Analysis, Learning).

**Side panel** — reorganized into **Overview** (snapshot cards for context,
cache, 5h, 7d), **Map** (token heatmap + click-to-jump), **Tools**, **Prompts**,
**Export**, **Settings**.

**Export** — copy/download Markdown (now with title/date/message-count/token
metadata), JSON, print→PDF view, plus: copy last answer, copy last code block,
insert a summary prompt, download only your messages or only Claude's, and
download a message range.

**Model advisor** — chip above the composer with live tokens and a suggested
model (Haiku/Sonnet/Opus) + Apply; optional experimental auto-apply.

## Keyboard shortcuts

- `/` at the start of the composer → prompt palette (↑↓, Enter, Esc)
- `Ctrl/Cmd+Shift+K` → Quick Tools
- `Ctrl/Cmd+Shift+U` → panel Overview (usage snapshot)
- `Ctrl/Cmd+Shift+E` → panel Export
- `Esc` closes any popover, the palette, or the panel
- Panel tabs: `←`/`→` to move between tabs

## Accessibility

Aria labels on all controls, visible focus rings, focus trapping + restoration in
the panel and popovers, Escape everywhere, WCAG-aware contrast in both themes,
minimum ~28–34px targets, level *labels* (never color alone), a polite live
region announcing toasts, and reduced motion honored automatically via
`prefers-reduced-motion` or forced via Settings. High-contrast mode strengthens
borders and focus outlines.

## Install (unpacked)

**Chrome / Edge / Brave** — `chrome://extensions` → enable **Developer mode** →
**Load unpacked** → select this folder → open any `claude.ai` chat.

**Firefox** (temporary, until restart) — `about:debugging#/runtime/this-firefox`
→ **Load Temporary Add-on…** → pick `manifest.json`.

## Theming note

Surfaces use the extension's own solid colors; light vs dark is chosen by
**measuring the page's background luminance** at runtime (`.ct-dark`). It never
relies on claude.ai's CSS channel variables, which keeps everything opaque and
legible regardless of how claude implements its theme.

## Knobs you may need to tweak

Everything that touches claude.ai's live DOM is behind selector lists in
**`src/content/constants.js` → `CT.SEL`**, tried in order with graceful fallback:

- `TURNS` — Chat Map jump targets (falls back to text matching).
- `COMPOSER` — the message box (palette, draft meter, bottom-bar anchor, tool insertion).
- `MODEL_TRIGGER` / `MENU_ITEM` — only for model Apply/auto-apply. Most fragile;
  auto-apply is **off by default** and fails quietly with a toast.

The model heuristic lives in `src/content/model.js` (`suggestModel`). Usage level
thresholds live in `src/content/usage.js` (`level`).

## Privacy

All processing is local. No external servers, analytics, tracking, or remote
code. The fetch bridge **reads passively** and never mutates claude.ai requests
or responses. The `lastActiveOrg` cookie is read only to call claude.ai's own
conversation/usage endpoints. Token counting uses a bundled tokenizer.

## Credits & license

Token counting via [gpt-tokenizer](https://github.com/niieani/gpt-tokenizer)
(MIT — see THIRD_PARTY_NOTICES.md). MIT licensed.
